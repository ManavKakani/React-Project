import './App.css';

import Profile from './components/Profile';

function App() {
  return (
    <>
      <Profile />
      <Profile avtarUrl='https://i.imgur.com/5cmyRGA.jpg' />
      <Profile avtarUrl='https://i.imgur.com/OKS67lh.jpg' />
      <Profile avtarUrl='https://i.imgur.com/1bX5QH6.jpg' />
    </>
  );
}

export default App;
