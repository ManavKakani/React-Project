export function getImageUrl(imgid) {
    return `https://i.imgur.com/${imgid}.jpg`
}
