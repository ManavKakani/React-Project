import './App.css';

import Profile from './components/Profile';

function App() {
  return (
    <>
      <Profile name="asdfas" border={true} />
      <Profile name="asdfas" avtarUrl='5cmyRGA' border={true}  />
      <Profile name="asdfas" avtarUrl='OKS67lh' border={true}  />
      <Profile name="asdfas" avtarUrl='1bX5QH6' border={true}  />
    </>
  );
}

export default App;
