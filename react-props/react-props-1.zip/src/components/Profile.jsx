

export default function Profile({ avtarUrl = 'https://i.imgur.com/YfeOqp2.jpg' }) {
    return (
        <img
            className="avatar"
            src={avtarUrl}
            alt="Lin Lanying"
            width={100}
            height={100}
        />
    );
}
