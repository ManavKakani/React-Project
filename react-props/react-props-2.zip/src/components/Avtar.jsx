import React from 'react'
import { getImageUrl } from '../helpers'

const Avtar = ({ avtarUrl = '5cmyRGA', border }) => {
    return (
        border && <img
            className="avatar"
            src={getImageUrl(avtarUrl)}
            alt="Lin Lanying"
            width={100}
            height={100}
        />
    )
}

export default Avtar